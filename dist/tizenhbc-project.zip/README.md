# Tizen Homebrew Channel

A 16:9 recreation of the Wii **Homebrew Channel** for Samsung Tizen TVs, packaged as an ES5 web widget. It keeps the original intro, logo, bubbles, 4×5 channel grid, hand cursor, status icons and button art, then adds a real xterm.js terminal and a small companion service for installing and running homebrew.

![The Homebrew Channel](app/res/img/logo.png)

## Features

- **Authentic intro** with the HBC logo and the two **Exit** / **Start** buttons.
- **Original channel UI**: bubble background, 4×5 grid, list view, hand cursor, page arrows, status icons and Home menu.
- **24-bit xterm.js terminal** with 256-colour ANSI, true colour, scrollback, fit-to-screen resizing and PTY input.
- **Virtual keyboard** with letters, symbols, Ctrl/Alt/Shift, arrows, Home/End, Page Up/Down, F1–F10 and terminal special keys.
- **Samsung remotes**: slim Smart Remote and full remote. Arrows, OK and BACK reach every action; colour buttons are shortcuts.
- **Program catalog** in a documented JSON format for C# `.dll` programs and native ARM ELF executables.
- **Offline-first**: the bundled catalog, built-in channels and READMEs work without internet.
- **Companion `hbc-srv`** for installs, SHA-256 verification, PTY sessions and process lifecycle.
- **Original assets and fonts** from the GPL-2.0 Homebrew Channel release.

## Quick start

Requirements:

- Tizen Studio with the TV profile and an author certificate.
- Node.js (used by the build script for JavaScript and JSON checks).
- A Samsung TV in developer mode with `sdb` access.
- Optional: .NET SDK 9 (or any SDK that can target `netcoreapp3.1`) to build the companion.
- Optional: `dotnet` runtime on the TV for C# programs.

### 1. Build the widget

```sh
./tools/build.sh
```

This checks every JS file, validates the JSON, and packages:

```text
dist/tizenhbc.wgt
```

The signing profile defaults to `tv`; override it with `HBC_PROFILE=myprofile`.

### 2. Install the widget

```sh
./tools/install-hbc.sh 192.168.1.50
```

The script connects `sdb`, then installs `dist/tizenhbc.wgt` with `tizen install`. You can also install the `.wgt` manually through Tizen Studio or `sdb`.

### 3. Build and install the companion (optional)

```sh
./tools/build-companion.sh
```

Output:

```text
dist/hbc-srv/
  hbc-srv.dll
  hbc-srv.deps.json
  hbc-srv.runtimeconfig.json
  programs/
    tvfetch/
```

Copy that directory to the TV, for example:

```sh
sdb push dist/hbc-srv /opt/usr/home/owner/share/hbc-srv
sdb shell "chmod +x /opt/usr/home/owner/share/hbc-srv/hbc-srv"
sdb shell "/opt/usr/home/owner/share/hbc-srv/hbc-srv"
```

Start it with the TV's .NET host if the apphost is not usable:

```sh
dotnet /opt/usr/home/owner/share/hbc-srv/hbc-srv.dll
```

The service listens on `127.0.0.1:2325` only. `HBC_PORT`, `HBC_INSTALL_ROOT`, `HBC_BUNDLE_ROOT` and `HBC_DATA_ROOT` override the defaults.

### 4. Install a program

Open **Programs** in the channel, choose an entry, then **Install**. The service copies bundled programs or downloads remote files into `/opt/usr/home/hbc/programs/<id>`, verifies checksums and writes `program.json` plus the README.

Launching a program opens the terminal when `terminal: true`. Programs with `keyboard: true` open the virtual keyboard automatically.

## Controls

| Action | Remote | Keyboard |
| --- | --- | --- |
| Move selection | Arrows | Arrows |
| Start / open | OK / Enter | Enter |
| Home menu | BACK | Escape |
| Program info | Red | F1 |
| Start / install | Green | F2 |
| Grid / list view | Yellow | F3 |
| Refresh catalog | Blue | F4 |
| Previous / next page | Channel Up/Down | Page Up/Down |
| Terminal keyboard | Green or Red | F2 |
| Terminal hide | Yellow | — |
| Terminal kill | Blue | — |
| Terminal Escape | Play/Pause | — |
| Exit to TV | Home menu → Exit to TV | — |

## Catalog format

Programs are described by `app/res/programs.json` and the schema in [`schemas/programs.schema.json`](schemas/programs.schema.json). A program declares:

- its directory and README;
- `language`: `csharp` or `native`;
- `runtime`: `dotnet` or `elf`;
- its `.dll` or executable entry point;
- `terminal` and `keyboard` flags;
- files with `path`, `url`, `sha256`, `size` and `executable`.

The full field reference, examples and publishing steps are in [`docs/PROGRAMS.md`](docs/PROGRAMS.md).

The default remote manifest URL is:

```text
https://raw.githubusercontent.com/HackSucks/SamPwn-Programs/main/programs.json
```

Change it in **Settings → Catalog URL** to use a fork. The bundled TVFetch entry uses `"bundled": true`, so it installs from `hbc-srv/programs/tvfetch` without network access.

## Project layout

```text
app/                    Tizen widget (ES5)
  index.html
  config.xml
  css/hbc.css
  js/                   util, audio, remote, bridge, catalog, ui, keyboard,
                        terminal, intro, main, app
  res/                  audio, fonts, icons, original art, programs.json
  vendor/xterm/         xterm.js 4.19.0 + fit addon 0.5.0
companion/hbc-srv/      .NET Core 3.1 companion service
programs/tvfetch/       bundled TVFetch build, source and README
schemas/                catalog JSON Schema
docs/                   program format and architecture
tools/                  build, install, icon and packaging scripts
dist/                   generated .wgt, service output and zip
```

## Music

The intro uses `app/res/audio/intro.mp3`; the looping background track is `app/res/audio/bgm.mp3`. Both are the files supplied for this personal port and are not relicensed by the project. Music and sound effects can be disabled in Settings.

## Credits

- Original Homebrew Channel art, logo, layout and fonts: **Team Twiizers / fail0verflow**, GPL-2.0.
- Droid Sans and Droid Sans Bold: the redistributable fonts shipped with the open-source HBC release.
- Adwaita Mono: used by SamPwn as its terminal font.
- xterm.js: MIT.
- TVFetch and SamPwn-Programs: **HackSucks**.
- Tizen port, ES5 widget, companion service and documentation: Tizen HBC contributors.

The Homebrew Channel name and logo belong to their original authors. This is a fan port, not an official Nintendo, Team Twiizers or Samsung product.

## License

GPL-2.0. See [`COPYING`](COPYING). The original Homebrew Channel assets are distributed under the same license. The supplied music files remain the property of their respective owners.

/* The HBC intro: logo, bubbles, Exit / Start. */
(function (window, document) {
  'use strict';

  var HBC = window.HBC = window.HBC || {};
  var U = HBC.Util;

  var elIntro = U.$('intro');
  var btnExit = U.$('btnExit');
  var btnStart = U.$('btnStart');
  var cursor = U.$('introCursor');
  var focusIndex = 1;
  var started = false;
  var buttons = [];

  function positionCursor() {
    var node = buttons[focusIndex];
    if (!node || !cursor) return;
    var rect = node.getBoundingClientRect();
    var cw = cursor.offsetWidth || window.innerWidth * 0.1;
    var ch = cursor.offsetHeight || window.innerWidth * 0.1;
    var left = rect.left + rect.width * 0.72 - cw * 0.45;
    var top = rect.top - ch * 0.55;
    cursor.style.left = Math.round(left) + 'px';
    cursor.style.top = Math.round(top) + 'px';
  }

  function setFocus(index) {
    focusIndex = index;
    U.toggleClass(btnExit, 'focus', index === 0);
    U.toggleClass(btnStart, 'focus', index === 1);
    positionCursor();
    if (HBC.Audio) HBC.Audio.sfx('move');
  }

  function activate() {
    if (focusIndex === 0) exit();
    else start();
  }

  function start() {
    if (started) return;
    started = true;
    if (HBC.Audio) {
      HBC.Audio.sfx('boot');
      HBC.Audio.stopIntro(700);
    }
    U.addClass(elIntro, 'out');
    var fade = U.$('fade');
    U.addClass(fade, 'on');
    window.setTimeout(function () {
      U.addClass(elIntro, 'hidden');
      U.removeClass(fade, 'on');
      if (HBC.Main) HBC.Main.enter();
      if (HBC.Audio) HBC.Audio.startBgm();
    }, 620);
  }

  function exit() {
    if (started) return;
    started = true;
    if (HBC.Audio) HBC.Audio.stopIntro(450);
    var fade = U.$('fade');
    U.addClass(fade, 'on');
    window.setTimeout(function () {
      if (HBC.App) HBC.App.exit();
    }, 520);
  }

  function handleRemote(action) {
    if (started) return;
    if (action === 'left' || action === 'up') { setFocus(0); return; }
    if (action === 'right' || action === 'down') { setFocus(1); return; }
    if (action === 'enter') { activate(); return; }
    if (action === 'back' || action === 'exit') {
      HBC.Dialog.confirm('Exit', 'Leave the Homebrew Channel?', 'Exit', 'Stay', function (yes) {
        if (yes) exit();
      });
      return;
    }
  }

  function init() {
    buttons = [btnExit, btnStart];
    U.on(btnExit, 'click', function () { setFocus(0); exit(); });
    U.on(btnStart, 'click', function () { setFocus(1); start(); });
    U.on(btnExit, 'mouseenter', function () { setFocus(0); });
    U.on(btnStart, 'mouseenter', function () { setFocus(1); });
    U.on(window, 'resize', positionCursor);
    setFocus(1);
    U.addClass(cursor, 'show');
    positionCursor();
  }

  function show() {
    U.removeClass(elIntro, 'hidden');
    U.removeClass(elIntro, 'out');
    started = false;
    setFocus(1);
    if (HBC.Audio) HBC.Audio.playIntro();
    window.setTimeout(positionCursor, 120);
  }

  HBC.Intro = {
    init: init,
    show: show,
    start: start,
    exit: exit,
    handleRemote: handleRemote,
    isStarted: function () { return started; }
  };
})(window, document);

/* Music + synthesized HBC-style interface sounds. */
(function (window) {
  'use strict';

  var HBC = window.HBC = window.HBC || {};
  var U = HBC.Util;

  var intro = null;
  var bgm = null;
  var ctx = null;
  var unlocked = false;
  var bgmWanted = false;
  var ducked = false;

  function musicEnabled() {
    return !HBC.Settings || HBC.Settings.music !== false;
  }
  function sfxEnabled() {
    return !HBC.Settings || HBC.Settings.sfx !== false;
  }

  function ensureCtx() {
    if (ctx) return ctx;
    try {
      var Ctor = window.AudioContext || window.webkitAudioContext;
      if (Ctor) ctx = new Ctor();
    } catch (e) { ctx = null; }
    return ctx;
  }

  function unlock() {
    unlocked = true;
    var c = ensureCtx();
    if (c && c.state === 'suspended' && c.resume) {
      try { c.resume(); } catch (e) {}
    }
    if (intro && intro.paused && !intro.ended) {
      tryPlay(intro);
    }
    if (bgmWanted && bgm && bgm.paused) {
      tryPlay(bgm);
    }
  }

  function tryPlay(el) {
    if (!el) return;
    try {
      var p = el.play();
      if (p && p.catch) p.catch(function () {});
    } catch (e) {}
  }

  function fade(el, to, ms, done) {
    if (!el) { if (done) done(); return; }
    var from = el.volume;
    var start = new Date().getTime();
    var timer = window.setInterval(function () {
      var t = (new Date().getTime() - start) / ms;
      if (t >= 1) {
        window.clearInterval(timer);
        el.volume = U.clamp(to, 0, 1);
        if (done) done();
        return;
      }
      el.volume = U.clamp(from + (to - from) * t, 0, 1);
    }, 40);
  }

  function init() {
    intro = new Audio('res/audio/intro.mp3');
    intro.preload = 'auto';
    intro.volume = 0.82;

    bgm = new Audio('res/audio/bgm.mp3');
    bgm.preload = 'auto';
    bgm.loop = true;
    bgm.volume = 0.34;
  }

  function playIntro() {
    if (!intro || !musicEnabled()) return;
    intro.currentTime = 0;
    tryPlay(intro);
  }

  function stopIntro(ms) {
    if (!intro) return;
    fade(intro, 0, ms || 500, function () {
      try { intro.pause(); } catch (e) {}
    });
  }

  function startBgm() {
    if (!bgm || !musicEnabled()) return;
    bgmWanted = true;
    bgm.volume = ducked ? 0.12 : 0.34;
    try { bgm.currentTime = 0; } catch (e) {}
    tryPlay(bgm);
  }

  function stopBgm(ms) {
    bgmWanted = false;
    if (!bgm) return;
    fade(bgm, 0, ms || 400, function () {
      try { bgm.pause(); } catch (e) {}
    });
  }

  function setDucked(on) {
    ducked = !!on;
    if (bgm && bgmWanted) fade(bgm, ducked ? 0.10 : 0.34, 350);
  }

  function beep(freq, endFreq, dur, type, gain, delay) {
    if (!sfxEnabled()) return;
    var c = ensureCtx();
    if (!c) return;
    if (c.state === 'suspended' && c.resume) {
      try { c.resume(); } catch (e) {}
    }
    var t0 = c.currentTime + (delay || 0);
    var osc = c.createOscillator();
    var g = c.createGain();
    osc.type = type || 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    if (endFreq && osc.frequency.exponentialRampToValueAtTime) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), t0 + dur);
    }
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain || 0.12, t0 + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g);
    g.connect(c.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.03);
  }

  function noise(dur, gain) {
    if (!sfxEnabled()) return;
    var c = ensureCtx();
    if (!c) return;
    var len = Math.floor(c.sampleRate * dur);
    var buffer = c.createBuffer(1, len, c.sampleRate);
    var data = buffer.getChannelData(0);
    for (var i = 0; i < len; i++) {
      data[i] = (Math.random() * 2 - 1) * (1 - i / len);
    }
    var src = c.createBufferSource();
    var g = c.createGain();
    g.gain.value = gain || 0.05;
    src.buffer = buffer;
    src.connect(g);
    g.connect(c.destination);
    src.start(0);
  }

  function sfx(name) {
    if (!sfxEnabled()) return;
    if (name === 'move') beep(620, 760, 0.055, 'sine', 0.06);
    else if (name === 'select') { beep(880, 1180, 0.075, 'sine', 0.09); beep(1320, 1560, 0.06, 'sine', 0.05, 0.05); }
    else if (name === 'back') beep(440, 300, 0.09, 'sine', 0.07);
    else if (name === 'launch') {
      beep(420, 1260, 0.32, 'sine', 0.10);
      beep(630, 1890, 0.30, 'triangle', 0.05, 0.04);
      noise(0.20, 0.035);
    } else if (name === 'error') {
      beep(180, 120, 0.22, 'square', 0.07);
      beep(140, 90, 0.26, 'square', 0.05, 0.10);
    } else if (name === 'pop') {
      beep(900, 1400, 0.035, 'sine', 0.035);
    } else if (name === 'boot') {
      beep(220, 880, 0.55, 'sine', 0.07);
      beep(440, 1320, 0.50, 'triangle', 0.035, 0.10);
    }
  }

  function refreshSettings() {
    if (!musicEnabled()) {
      stopBgm(200);
      stopIntro(200);
    } else if (bgmWanted && bgm && bgm.paused) {
      tryPlay(bgm);
    }
  }

  HBC.Audio = {
    init: init,
    unlock: unlock,
    playIntro: playIntro,
    stopIntro: stopIntro,
    startBgm: startBgm,
    stopBgm: stopBgm,
    setDucked: setDucked,
    sfx: sfx,
    refreshSettings: refreshSettings
  };
})(window);

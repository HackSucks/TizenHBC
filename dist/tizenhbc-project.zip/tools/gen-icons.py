#!/usr/bin/env python3
"""Generate the Tizen Homebrew Channel icon set.

Run from the repository root:
    python3 tools/gen-icons.py

All icons are rendered locally; no network access is required.
"""
import math
import os
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "app", "res", "icons")
FONT_BOLD = os.path.join(ROOT, "app", "res", "font", "droidbold.ttf")
FONT_REG = os.path.join(ROOT, "app", "res", "font", "droid.ttf")

BANNER = (512, 192)
SQUARE = (512, 512)


def font(path, size):
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def lerp(a, b, t):
    return int(round(a + (b - a) * t))


def gradient(size, top, bottom):
    w, h = size
    im = Image.new("RGB", size, top)
    px = im.load()
    for y in range(h):
        t = y / max(1, h - 1)
        c = (lerp(top[0], bottom[0], t), lerp(top[1], bottom[1], t), lerp(top[2], bottom[2], t))
        for x in range(w):
            px[x, y] = c
    return im


def rounded_mask(size, radius):
    mask = Image.new("L", size, 0)
    d = ImageDraw.Draw(mask)
    d.rounded_rectangle([0, 0, size[0] - 1, size[1] - 1], radius=radius, fill=255)
    return mask


def glossy(im, radius=18):
    w, h = im.size
    shine = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(shine)
    d.rounded_rectangle([2, 2, w - 3, int(h * 0.46)], radius=radius,
                        fill=(255, 255, 255, 30))
    im = im.convert("RGBA")
    im.alpha_composite(shine)
    # thin highlight along the top edge
    edge = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(edge)
    d.rounded_rectangle([1, 1, w - 2, h - 2], radius=radius,
                        outline=(255, 255, 255, 70), width=2)
    im.alpha_composite(edge)
    return im


def bubble(d, cx, cy, r, color=(255, 255, 255, 55)):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], outline=color, width=max(2, r // 8))
    d.arc([cx - r, cy - r, cx + r, cy + r], 200, 320, fill=(255, 255, 255, 130),
          width=max(2, r // 10))


def text_center(d, box, text, f, fill, shadow=True):
    x0, y0, x1, y1 = box
    if shadow:
        d.text(((x0 + x1) / 2 + 2, (y0 + y1) / 2 + 3), text, font=f,
               fill=(0, 0, 0, 180), anchor="mm")
    d.text(((x0 + x1) / 2, (y0 + y1) / 2), text, font=f, fill=fill, anchor="mm")


def save(im, name, radius=None):
    if radius is not None:
        im = im.convert("RGBA")
        im.putalpha(rounded_mask(im.size, radius))
    path = os.path.join(OUT, name)
    im.save(path, "PNG", optimize=True)
    print("wrote", os.path.relpath(path, ROOT), im.size)


def make_tvfetch():
    im = gradient(BANNER, (10, 44, 54), (4, 16, 24)).convert("RGBA")
    d = ImageDraw.Draw(im)
    # scanline-ish glow
    for i in range(0, BANNER[0], 8):
        d.line([(i, 0), (i - 80, BANNER[1])], fill=(20, 90, 110, 22), width=2)
    # TV body
    tv = [34, 38, 300, 154]
    d.rounded_rectangle(tv, radius=16, fill=(8, 22, 30, 255), outline=(90, 220, 255, 255), width=4)
    d.rounded_rectangle([52, 54, 282, 130], radius=8, fill=(12, 36, 48, 255))
    # colored bars
    bars = [(64, (255, 92, 120)), (100, (255, 190, 80)), (136, (110, 235, 160)),
            (172, (90, 200, 255)), (208, (190, 140, 255))]
    for x, c in bars:
        h = 18 + ((x * 7) % 30)
        d.rounded_rectangle([x, 116 - h, x + 24, 116], radius=4, fill=c + (255,))
    # antenna
    d.line([(110, 38), (80, 16)], fill=(90, 220, 255, 220), width=4)
    d.line([(150, 38), (180, 16)], fill=(90, 220, 255, 220), width=4)
    d.ellipse([74, 10, 86, 22], fill=(90, 220, 255, 255))
    d.ellipse([174, 10, 186, 22], fill=(90, 220, 255, 255))
    # text
    f = font(FONT_BOLD, 58)
    d.text((324, 70), "TVFetch", font=f, fill=(235, 250, 255, 255))
    f2 = font(FONT_REG, 24)
    d.text((326, 128), "SYSTEM INFO", font=f2, fill=(110, 220, 240, 255))
    bubble(d, 448, 36, 22)
    save(glossy(im, 20), "tvfetch.png")


def make_about():
    im = gradient(BANNER, (8, 48, 68), (3, 14, 24)).convert("RGBA")
    d = ImageDraw.Draw(im)
    for i in range(6):
        bubble(d, 40 + i * 92, 40 + (i * 37) % 110, 14 + (i * 9) % 26)
    # wave
    pts = []
    for x in range(0, BANNER[0], 6):
        y = 132 + math.sin(x / 44.0) * 16
        pts.append((x, y))
    d.line(pts, fill=(90, 210, 245, 210), width=5, joint="curve")
    f = font(FONT_BOLD, 46)
    text_center(d, (250, 20, 500, 120), "HBC", f, (255, 255, 255, 255))
    f2 = font(FONT_REG, 22)
    text_center(d, (250, 110, 500, 160), "TIZEN EDITION", f2, (120, 220, 245, 255))
    save(glossy(im, 20), "about.png")


def make_settings():
    im = gradient(BANNER, (34, 34, 52), (10, 12, 20)).convert("RGBA")
    d = ImageDraw.Draw(im)
    cx, cy, r = 104, 96, 56
    # gear
    for i in range(12):
        a = i * math.pi / 6
        x = cx + math.cos(a) * (r + 8)
        y = cy + math.sin(a) * (r + 8)
        d.ellipse([x - 10, y - 10, x + 10, y + 10], fill=(190, 205, 220, 255))
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(150, 168, 190, 255))
    d.ellipse([cx - 24, cy - 24, cx + 24, cy + 24], fill=(20, 24, 34, 255))
    f = font(FONT_BOLD, 46)
    d.text((200, 62), "Settings", font=f, fill=(235, 240, 250, 255))
    f2 = font(FONT_REG, 22)
    d.text((202, 120), "SERVICE · AUDIO · VIEW", font=f2, fill=(160, 175, 195, 255))
    save(glossy(im, 20), "settings.png")


def make_programs():
    im = gradient(BANNER, (28, 20, 58), (8, 8, 20)).convert("RGBA")
    d = ImageDraw.Draw(im)
    colors = [(255, 110, 140), (255, 190, 80), (110, 230, 160), (90, 200, 255),
              (190, 140, 255), (255, 150, 90)]
    for i in range(6):
        x = 34 + (i % 3) * 74
        y = 30 + (i // 3) * 70
        d.rounded_rectangle([x, y, x + 60, y + 56], radius=10,
                            fill=(18, 18, 32, 255), outline=colors[i] + (255,), width=3)
        d.rounded_rectangle([x + 10, y + 10, x + 50, y + 30], radius=4,
                            fill=colors[i] + (200,))
    f = font(FONT_BOLD, 44)
    d.text((280, 56), "Programs", font=f, fill=(240, 235, 255, 255))
    f2 = font(FONT_REG, 22)
    d.text((282, 112), "SAM PWN CATALOG", font=f2, fill=(180, 165, 230, 255))
    save(glossy(im, 20), "programs.png")


def make_app_icon():
    im = gradient(SQUARE, (10, 58, 86), (2, 10, 20)).convert("RGBA")
    d = ImageDraw.Draw(im)
    for i in range(12):
        bubble(d, 40 + (i * 71) % 440, 60 + (i * 113) % 400, 18 + (i * 13) % 46)
    # big bubble
    d.ellipse([110, 120, 402, 412], fill=(16, 70, 96, 120),
              outline=(150, 235, 255, 200), width=8)
    d.arc([110, 120, 402, 412], 200, 320, fill=(255, 255, 255, 220), width=10)
    f = font(FONT_BOLD, 190)
    text_center(d, (100, 120, 412, 340), "HBC", f, (255, 255, 255, 255))
    f2 = font(FONT_REG, 34)
    text_center(d, (90, 330, 422, 410), "HOMEBREW", f2, (150, 230, 250, 255))
    save(glossy(im, 96), "app-icon.png", radius=96)
    # Tizen root icon is a plain 512 square (the store masks it)
    save(im, "../../icon.png")


def make_welcome():
    im = gradient(BANNER, (8, 42, 62), (4, 14, 24)).convert("RGBA")
    d = ImageDraw.Draw(im)
    for i in range(8):
        bubble(d, 30 + i * 70, 30 + (i * 47) % 130, 12 + (i * 7) % 24)
    f = font(FONT_BOLD, 44)
    d.text((38, 40), "Welcome", font=f, fill=(255, 255, 255, 255))
    f2 = font(FONT_REG, 22)
    d.text((40, 100), "START HERE", font=f2, fill=(140, 220, 240, 255))
    save(glossy(im, 20), "welcome.png")


def main():
    os.makedirs(OUT, exist_ok=True)
    make_app_icon()
    make_tvfetch()
    make_about()
    make_settings()
    make_programs()
    make_welcome()


if __name__ == "__main__":
    main()

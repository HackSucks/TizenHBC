#!/bin/sh
# Publish the companion service for linux-arm and stage its program bundle.
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT="$ROOT/dist/hbc-srv"
RID=${HBC_RID:-linux-arm}

cd "$ROOT"

echo "==> Publishing hbc-srv ($RID)"
rm -rf "$OUT"
dotnet publish companion/hbc-srv/hbc-srv.csproj \
  -c Release \
  -r "$RID" \
  --self-contained false \
  -o "$OUT"

echo "==> Staging bundled programs"
rm -rf "$OUT/programs"
mkdir -p "$OUT/programs"
cp -R programs/. "$OUT/programs/"

echo "==> Built $OUT"
find "$OUT" -maxdepth 2 -type f | sort
